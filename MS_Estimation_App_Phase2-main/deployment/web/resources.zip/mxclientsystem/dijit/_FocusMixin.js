//>>built
define("dijit/_FocusMixin",["./focus","./_WidgetBase","dojo/_base/declare","dojo/_base/lang"],function(a,b,c,d){d.extend(b,{focused:!1,onFocus:function(){},onBlur:function(){},_onFocus:function(){this.onFocus()},_onBlur:function(){this.onBlur()}});return c("dijit._FocusMixin",null,{_focusManager:a})});
